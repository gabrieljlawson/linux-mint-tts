#!/bin/bash

# =============================================================================
# TTS Keyboard Shortcut Creation Script
# Creates Cinnamon system-wide keyboard shortcuts for TTS control.
#
# Cinnamon compatibility note:
# Custom shortcut object IDs must use Cinnamon's standard customN pattern
# (custom0, custom1, custom2, ...). Human-readable names are stored separately.
# =============================================================================

set -u
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"

USERNAME=$(whoami)
VOICES_DIR="/home/$USERNAME/Voices"
CUSTOM_LIST_SCHEMA="org.cinnamon.desktop.keybindings"
CUSTOM_BINDING_SCHEMA="org.cinnamon.desktop.keybindings.custom-keybinding"
STATUS_FILE="/tmp/tts_shortcut_status.txt"

OLD_TTS_IDS=("tts-start" "tts-pause" "tts-pause-slash" "tts-pause-p" "tts-stop")

SHORTCUT_NAMES=("TTS Start Speaking" "TTS Pause Resume" "TTS Stop Speaking")
SHORTCUT_COMMANDS=(
    "$VOICES_DIR/speak_clipboard.sh"
    "$VOICES_DIR/tts_control.sh toggle"
    "$VOICES_DIR/tts_control.sh stop"
)

CTRL_BINDINGS=("<Control><Alt>period" "<Control><Alt>slash" "<Control><Alt>comma")
CTRL_LABELS=("Ctrl + Alt + Period (.)" "Ctrl + Alt + Slash (/)" "Ctrl + Alt + Comma (,)")
SUPER_BINDINGS=("<Super><Alt>period" "<Super><Alt>slash" "<Super><Alt>comma")
SUPER_LABELS=("Super + Alt + Period (.)" "Super + Alt + Slash (/)" "Super + Alt + Comma (,)")

: > "$STATUS_FILE"

need_command() {
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "ERROR: Required command not found: $1"
        echo "This script is intended for Linux Mint Cinnamon."
        exit 1
    fi
}

for cmd in gsettings sed grep tr awk xargs; do
    need_command "$cmd"
done

if [ ! -d "$VOICES_DIR" ]; then
    echo "ERROR: Voices directory not found at $VOICES_DIR"
    echo "Please run install_voices.sh or install.sh first."
    exit 1
fi

if [ ! -x "$VOICES_DIR/speak_clipboard.sh" ]; then
    echo "ERROR: speak_clipboard.sh not found or not executable in $VOICES_DIR"
    echo "Please run install_voices.sh or install.sh first."
    exit 1
fi

if [ ! -x "$VOICES_DIR/tts_control.sh" ]; then
    echo "ERROR: tts_control.sh not found or not executable in $VOICES_DIR"
    echo "Please run install_voices.sh or install.sh first."
    exit 1
fi

echo "Creating TTS keyboard shortcuts for user: $USERNAME"
echo "Shortcut commands use fully expanded absolute paths generated from the current username."
echo "Cinnamon-compatible shortcut IDs use the standard customN format."
echo "If Ctrl+Alt shortcuts conflict, the installer will try the Super+Alt set instead."
echo ""

schema_exists() {
    gsettings list-schemas | grep -qx "$1"
}

if ! schema_exists "$CUSTOM_LIST_SCHEMA"; then
    echo "ERROR: Cinnamon custom shortcut schema not found: $CUSTOM_LIST_SCHEMA"
    echo "This shortcut creator currently supports Linux Mint Cinnamon."
    exit 1
fi

CURRENT_RAW=$(gsettings get "$CUSTOM_LIST_SCHEMA" custom-list 2>/dev/null || echo "@as []")

parse_ids() {
    echo "$1" |
        sed 's/^@as //' |
        tr -d "[]'" |
        tr ',' '\n' |
        sed 's/^ *//;s/ *$//' |
        sed '/^$/d'
}

clean_gsettings_string() {
    sed "s/^'//;s/'$//"
}

get_binding_for_id() {
    local ID="$1"
    local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${ID}/"
    gsettings get "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" binding 2>/dev/null || echo "[]"
}

get_command_for_id() {
    local ID="$1"
    local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${ID}/"
    gsettings get "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" command 2>/dev/null | clean_gsettings_string || echo ""
}

get_name_for_id() {
    local ID="$1"
    local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${ID}/"
    gsettings get "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" name 2>/dev/null | clean_gsettings_string || echo "$ID"
}

quote_list() {
    if [ "$#" -eq 0 ]; then
        echo "@as []"
        return
    fi

    local OUT="["
    local FIRST=1
    local ITEM
    for ITEM in "$@"; do
        if [ "$FIRST" -eq 1 ]; then
            OUT="$OUT'$ITEM'"
            FIRST=0
        else
            OUT="$OUT, '$ITEM'"
        fi
    done
    OUT="$OUT]"
    echo "$OUT"
}

array_contains() {
    local SEEK="$1"
    shift
    local ITEM
    for ITEM in "$@"; do
        if [ "$ITEM" = "$SEEK" ]; then
            return 0
        fi
    done
    return 1
}

is_old_tts_id() {
    local ID="$1"
    array_contains "$ID" "${OLD_TTS_IDS[@]}"
}

is_our_command() {
    local COMMAND="$1"
    local ITEM
    for ITEM in "${SHORTCUT_COMMANDS[@]}"; do
        if [ "$COMMAND" = "$ITEM" ]; then
            return 0
        fi
    done
    return 1
}

is_exact_tts_name() {
    local NAME="$1"
    local ITEM
    for ITEM in "${SHORTCUT_NAMES[@]}"; do
        if [ "$NAME" = "$ITEM" ]; then
            return 0
        fi
    done
    return 1
}

id_in_use() {
    local SEEK="$1"
    array_contains "$SEEK" "${USED_IDS[@]}"
}

allocate_custom_id() {
    local N=0
    local CANDIDATE
    while true; do
        CANDIDATE="custom$N"
        if ! id_in_use "$CANDIDATE"; then
            echo "$CANDIDATE"
            return
        fi
        N=$((N + 1))
    done
}

set_shortcut() {
    local SHORTCUT_ID="$1"
    local NAME="$2"
    local COMMAND="$3"
    local BINDING="$4"

    local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${SHORTCUT_ID}/"

    gsettings set "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" name "$NAME"
    gsettings set "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" command "$COMMAND"
    gsettings set "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" binding "['$BINDING']"
}

normalize_binding_one() {
    # Normalize a single Cinnamon binding so modifier order and aliases do not matter.
    # Examples that normalize the same:
    #   <Control><Alt>period
    #   <Primary><Alt>period
    #   <Alt><Control>period
    #   <Mod4><Alt>period == <Super><Alt>period
    local RAW="$1"
    local LOWER KEY OUT=""

    LOWER=$(echo "$RAW" | tr '[:upper:]' '[:lower:]')
    LOWER=$(echo "$LOWER" | sed 's/primary/control/g; s/mod4/super/g')

    if echo "$LOWER" | grep -q '<control>'; then OUT="${OUT}control+"; fi
    if echo "$LOWER" | grep -q '<super>'; then OUT="${OUT}super+"; fi
    if echo "$LOWER" | grep -q '<alt>'; then OUT="${OUT}alt+"; fi
    if echo "$LOWER" | grep -q '<shift>'; then OUT="${OUT}shift+"; fi

    KEY=$(echo "$LOWER" | sed 's/<[^>]*>//g' | tr -d "[]', \t")
    echo "${OUT}${KEY}"
}

binding_has() {
    local BINDING_LIST="$1"
    local BINDING="$2"
    local TARGET
    local ITEM
    local CLEANED

    TARGET=$(normalize_binding_one "$BINDING")

    # Convert a GSettings array like ['<Control><Alt>period', '<Super><Alt>period']
    # into one binding per line, then compare normalized forms.
    CLEANED=$(echo "$BINDING_LIST" | tr -d "[]'" | tr ',' '\n' | sed 's/^ *//;s/ *$//' | sed '/^$/d')

    while IFS= read -r ITEM; do
        if [ "$(normalize_binding_one "$ITEM")" = "$TARGET" ]; then
            return 0
        fi
    done <<< "$CLEANED"

    return 1
}

command_is_unique() {
    local DESIRED_COMMAND="$1"
    local COUNT=0
    local ITEM
    for ITEM in "${SHORTCUT_COMMANDS[@]}"; do
        if [ "$ITEM" = "$DESIRED_COMMAND" ]; then
            COUNT=$((COUNT + 1))
        fi
    done
    [ "$COUNT" -eq 1 ]
}

binding_conflict_report() {
    local BINDING="$1"
    local LABEL="$2"
    local DESIRED_COMMAND="$3"
    local EXISTING_ID EXISTING_BINDING EXISTING_COMMAND EXISTING_NAME

    # CRITICAL: scan every existing custom shortcut. Do not stop merely because
    # the desired TTS command also exists somewhere. A binding is safe only if no
    # unrelated command is using that same binding.
    for EXISTING_ID in "${ALL_IDS[@]}"; do
        EXISTING_BINDING=$(get_binding_for_id "$EXISTING_ID")
        if binding_has "$EXISTING_BINDING" "$BINDING"; then
            EXISTING_COMMAND=$(get_command_for_id "$EXISTING_ID")
            EXISTING_NAME=$(get_name_for_id "$EXISTING_ID")

            if [ "$EXISTING_COMMAND" != "$DESIRED_COMMAND" ]; then
                echo "$LABEL is already used by '$EXISTING_NAME' ($EXISTING_ID). Existing command: $EXISTING_COMMAND Needed command: $DESIRED_COMMAND"
                return 0
            fi
        fi
    done

    return 1
}

find_existing_id_for_command() {
    local DESIRED_COMMAND="$1"
    local EXISTING_ID EXISTING_COMMAND
    for EXISTING_ID in "${ALL_IDS[@]}"; do
        EXISTING_COMMAND=$(get_command_for_id "$EXISTING_ID")
        if [ "$EXISTING_COMMAND" = "$DESIRED_COMMAND" ]; then
            echo "$EXISTING_ID"
            return 0
        fi
    done
    return 1
}

find_existing_id_for_name() {
    local DESIRED_NAME="$1"
    local EXISTING_ID EXISTING_NAME
    for EXISTING_ID in "${ALL_IDS[@]}"; do
        EXISTING_NAME=$(get_name_for_id "$EXISTING_ID")
        if [ "$EXISTING_NAME" = "$DESIRED_NAME" ]; then
            echo "$EXISTING_ID"
            return 0
        fi
    done
    return 1
}

find_existing_id_for_shortcut_index() {
    local IDX="$1"
    local DESIRED_NAME="${SHORTCUT_NAMES[$IDX]}"
    local DESIRED_COMMAND="${SHORTCUT_COMMANDS[$IDX]}"
    local FOUND_ID=""

    if FOUND_ID=$(find_existing_id_for_name "$DESIRED_NAME"); then
        echo "$FOUND_ID"
        return 0
    fi

    if command_is_unique "$DESIRED_COMMAND" && FOUND_ID=$(find_existing_id_for_command "$DESIRED_COMMAND"); then
        echo "$FOUND_ID"
        return 0
    fi

    return 1
}

existing_scheme_is_complete_and_safe() {
    local SCHEME_NAME="$1"
    shift
    local BINDINGS=("$@")
    local i EXISTING_ID EXISTING_COMMAND EXISTING_BINDING REPORT

    for i in "${!SHORTCUT_NAMES[@]}"; do
        if ! EXISTING_ID=$(find_existing_id_for_shortcut_index "$i"); then
            return 1
        fi

        EXISTING_COMMAND=$(get_command_for_id "$EXISTING_ID")
        EXISTING_BINDING=$(get_binding_for_id "$EXISTING_ID")

        if [ "$EXISTING_COMMAND" != "${SHORTCUT_COMMANDS[$i]}" ]; then
            return 1
        fi

        if ! binding_has "$EXISTING_BINDING" "${BINDINGS[$i]}"; then
            return 1
        fi

        if REPORT=$(binding_conflict_report "${BINDINGS[$i]}" "$SCHEME_NAME" "${SHORTCUT_COMMANDS[$i]}"); then
            return 1
        fi
    done

    return 0
}

scheme_conflicts() {
    local LABEL_PREFIX="$1"
    shift
    local -n BINDINGS_REF=$1
    shift
    local -n LABELS_REF=$1
    local i REPORT
    SCHEME_CONFLICTS=()

    for i in "${!SHORTCUT_NAMES[@]}"; do
        if REPORT=$(binding_conflict_report "${BINDINGS_REF[$i]}" "${LABELS_REF[$i]}" "${SHORTCUT_COMMANDS[$i]}"); then
            SCHEME_CONFLICTS+=("$REPORT")
        fi
    done

    [ "${#SCHEME_CONFLICTS[@]}" -gt 0 ]
}


# Deduplicate current custom-list while preserving order.
mapfile -t RAW_IDS < <(parse_ids "$CURRENT_RAW")
ALL_IDS=()
for ID in "${RAW_IDS[@]}"; do
    if ! array_contains "$ID" "${ALL_IDS[@]}"; then
        ALL_IDS+=("$ID")
    fi
done

CHOSEN_SCHEME=""
echo "Keyboard Shortcut Status" >> "$STATUS_FILE"
echo "========================" >> "$STATUS_FILE"

echo "Checking for existing custom shortcut conflicts..."

# Preserve an already-complete TTS scheme on reinstall. This prevents a system
# that correctly fell back to Super+Alt from later switching back to Ctrl+Alt
# simply because a Ctrl conflict was removed.
if existing_scheme_is_complete_and_safe "Ctrl+Alt existing TTS shortcut" "${CTRL_BINDINGS[@]}"; then
    CHOSEN_SCHEME="CTRL"
    CHOSEN_BINDINGS=("${CTRL_BINDINGS[@]}")
    CHOSEN_LABELS=("${CTRL_LABELS[@]}")
    echo "  Existing complete Ctrl+Alt TTS shortcut set found. Leaving it as the active scheme."
elif existing_scheme_is_complete_and_safe "Super+Alt existing TTS shortcut" "${SUPER_BINDINGS[@]}"; then
    CHOSEN_SCHEME="SUPER"
    CHOSEN_BINDINGS=("${SUPER_BINDINGS[@]}")
    CHOSEN_LABELS=("${SUPER_LABELS[@]}")
    echo "  Existing complete Super+Alt TTS shortcut set found. Leaving it as the active scheme."
else
    CTRL_CONFLICTS=()
    if scheme_conflicts "Ctrl+Alt" CTRL_BINDINGS CTRL_LABELS; then
        CTRL_CONFLICTS=("${SCHEME_CONFLICTS[@]}")
    fi

    if [ "${#CTRL_CONFLICTS[@]}" -eq 0 ]; then
        CHOSEN_SCHEME="CTRL"
        CHOSEN_BINDINGS=("${CTRL_BINDINGS[@]}")
        CHOSEN_LABELS=("${CTRL_LABELS[@]}")
        echo "  No Ctrl+Alt shortcut conflicts found. Using Ctrl+Alt shortcut set."
    else
        echo "  Ctrl+Alt shortcut conflict found. Checking Super+Alt fallback set..."
        SUPER_CONFLICTS=()
        if scheme_conflicts "Super+Alt" SUPER_BINDINGS SUPER_LABELS; then
            SUPER_CONFLICTS=("${SCHEME_CONFLICTS[@]}")
        fi

        if [ "${#SUPER_CONFLICTS[@]}" -eq 0 ]; then
            CHOSEN_SCHEME="SUPER"
            CHOSEN_BINDINGS=("${SUPER_BINDINGS[@]}")
            CHOSEN_LABELS=("${SUPER_LABELS[@]}")
            echo "  Super+Alt fallback set is available. Using Super+Alt shortcut set."
            echo "Ctrl+Alt shortcut conflict found; Super+Alt fallback set was installed instead." >> "$STATUS_FILE"
            echo "" >> "$STATUS_FILE"
            echo "Ctrl+Alt conflicts detected:" >> "$STATUS_FILE"
            for LINE in "${CTRL_CONFLICTS[@]}"; do
                echo "  CONFLICT: $LINE" >> "$STATUS_FILE"
            done
        else
            CHOSEN_SCHEME="NONE"
            echo "  Both Ctrl+Alt and Super+Alt shortcut sets have conflicts. Existing shortcuts will be left unchanged."
            echo "Shortcut conflicts prevented automatic shortcut installation." >> "$STATUS_FILE"
            echo "" >> "$STATUS_FILE"
            echo "Ctrl+Alt conflicts:" >> "$STATUS_FILE"
            for LINE in "${CTRL_CONFLICTS[@]}"; do
                echo "  CONFLICT: $LINE" >> "$STATUS_FILE"
            done
            echo "" >> "$STATUS_FILE"
            echo "Super+Alt conflicts:" >> "$STATUS_FILE"
            for LINE in "${SUPER_CONFLICTS[@]}"; do
                echo "  CONFLICT: $LINE" >> "$STATUS_FILE"
            done
            echo "" >> "$STATUS_FILE"
            echo "No keyboard shortcuts were installed automatically. See README.txt → Keyboard Shortcut Conflicts." >> "$STATUS_FILE"
        fi
    fi
fi

# Build the new list by preserving unrelated shortcuts and one valid entry per
# desired TTS command. Old nonstandard TTS IDs are removed. Duplicate old TTS
# entries are removed. Existing compatible customN TTS entries are reused.
NEW_IDS=()
USED_IDS=()
USED_TTS_IDS=()
INSTALL_SUMMARY=()
CREATED_OR_UPDATED=()
LEFT_UNCHANGED=()
REMOVED_TTS_IDS=()

# Preserve unrelated shortcuts first.
for ID in "${ALL_IDS[@]}"; do
    NAME=$(get_name_for_id "$ID")
    COMMAND=$(get_command_for_id "$ID")
    if is_old_tts_id "$ID" || is_our_command "$COMMAND" || is_exact_tts_name "$NAME"; then
        :
    else
        NEW_IDS+=("$ID")
        USED_IDS+=("$ID")
    fi
done

if [ "$CHOSEN_SCHEME" != "NONE" ]; then
    for i in "${!SHORTCUT_NAMES[@]}"; do
        DESIRED_NAME="${SHORTCUT_NAMES[$i]}"
        DESIRED_COMMAND="${SHORTCUT_COMMANDS[$i]}"
        DESIRED_BINDING="${CHOSEN_BINDINGS[$i]}"
        DESIRED_LABEL="${CHOSEN_LABELS[$i]}"

        EXISTING_ID=""
        # Prefer matching by name, then by command when safe.
        if FOUND_ID=$(find_existing_id_for_name "$DESIRED_NAME"); then
            EXISTING_ID="$FOUND_ID"
        elif command_is_unique "$DESIRED_COMMAND" && FOUND_ID=$(find_existing_id_for_command "$DESIRED_COMMAND"); then
            EXISTING_ID="$FOUND_ID"
        fi

        if [ -z "$EXISTING_ID" ] || is_old_tts_id "$EXISTING_ID"; then
            NEW_ID=$(allocate_custom_id)
            USED_IDS+=("$NEW_ID")
            set_shortcut "$NEW_ID" "$DESIRED_NAME" "$DESIRED_COMMAND" "$DESIRED_BINDING"
            NEW_IDS+=("$NEW_ID")
            USED_TTS_IDS+=("$NEW_ID")
            CREATED_OR_UPDATED+=("$DESIRED_LABEL — $DESIRED_NAME")
            INSTALL_SUMMARY+=("$DESIRED_LABEL — $DESIRED_NAME")
            echo "  Created: $DESIRED_NAME ($DESIRED_BINDING) as $NEW_ID"
        else
            CURRENT_BINDING=$(get_binding_for_id "$EXISTING_ID")
            CURRENT_COMMAND=$(get_command_for_id "$EXISTING_ID")
            CURRENT_NAME=$(get_name_for_id "$EXISTING_ID")

            # If it is already exactly right, do not rewrite it. This avoids
            # needlessly invalidating Cinnamon's active shortcut registration.
            if [ "$CURRENT_COMMAND" = "$DESIRED_COMMAND" ] && binding_has "$CURRENT_BINDING" "$DESIRED_BINDING" && [ "$CURRENT_NAME" = "$DESIRED_NAME" ]; then
                LEFT_UNCHANGED+=("$DESIRED_LABEL — already present")
                echo "  Already present: $DESIRED_NAME ($DESIRED_BINDING) as $EXISTING_ID"
            else
                set_shortcut "$EXISTING_ID" "$DESIRED_NAME" "$DESIRED_COMMAND" "$DESIRED_BINDING"
                CREATED_OR_UPDATED+=("$DESIRED_LABEL — $DESIRED_NAME")
                echo "  Updated: $DESIRED_NAME ($DESIRED_BINDING) as $EXISTING_ID"
            fi

            NEW_IDS+=("$EXISTING_ID")
            USED_IDS+=("$EXISTING_ID")
            USED_TTS_IDS+=("$EXISTING_ID")
            INSTALL_SUMMARY+=("$DESIRED_LABEL — $DESIRED_NAME")
        fi
    done

    # Report stale/duplicate TTS entries removed from the list.
    for ID in "${ALL_IDS[@]}"; do
        NAME=$(get_name_for_id "$ID")
        COMMAND=$(get_command_for_id "$ID")
        if is_old_tts_id "$ID" || is_our_command "$COMMAND" || is_exact_tts_name "$NAME"; then
            if ! array_contains "$ID" "${USED_TTS_IDS[@]}"; then
                REMOVED_TTS_IDS+=("$ID")
            fi
        fi
    done
else
    # When both shortcut schemes conflict, remove existing TTS shortcuts from
    # Cinnamon so no stale or partially-conflicting TTS shortcut set remains.
    # Unrelated user shortcuts have already been preserved in NEW_IDS.
    for ID in "${ALL_IDS[@]}"; do
        NAME=$(get_name_for_id "$ID")
        COMMAND=$(get_command_for_id "$ID")
        if is_old_tts_id "$ID" || is_our_command "$COMMAND" || is_exact_tts_name "$NAME"; then
            REMOVED_TTS_IDS+=("$ID")
        fi
    done
fi

NEW_LIST=$(quote_list "${NEW_IDS[@]}")
gsettings set "$CUSTOM_LIST_SCHEMA" custom-list "$NEW_LIST"

echo ""
echo "Shortcut setup complete."

if [ "$CHOSEN_SCHEME" = "CTRL" ]; then
    echo "All TTS shortcuts installed successfully using the Ctrl+Alt shortcut set." >> "$STATUS_FILE"
elif [ "$CHOSEN_SCHEME" = "SUPER" ]; then
    echo "TTS shortcuts installed successfully using the Super+Alt fallback shortcut set." >> "$STATUS_FILE"
fi

if [ "${#LEFT_UNCHANGED[@]}" -gt 0 ]; then
    echo "" >> "$STATUS_FILE"
    echo "Already-present compatible shortcuts left unchanged:" >> "$STATUS_FILE"
    for ITEM in "${LEFT_UNCHANGED[@]}"; do
        echo "  $ITEM" >> "$STATUS_FILE"
    done
fi

if [ "${#CREATED_OR_UPDATED[@]}" -gt 0 ]; then
    echo "" >> "$STATUS_FILE"
    echo "Created or updated shortcuts:" >> "$STATUS_FILE"
    for ITEM in "${CREATED_OR_UPDATED[@]}"; do
        echo "  $ITEM" >> "$STATUS_FILE"
    done
fi

if [ "${#INSTALL_SUMMARY[@]}" -gt 0 ]; then
    echo "" >> "$STATUS_FILE"
    echo "Installed shortcut set:" >> "$STATUS_FILE"
    for ITEM in "${INSTALL_SUMMARY[@]}"; do
        echo "  $ITEM" >> "$STATUS_FILE"
    done
fi

if [ "${#REMOVED_TTS_IDS[@]}" -gt 0 ]; then
    echo "" >> "$STATUS_FILE"
    echo "Removed stale or duplicate TTS shortcut entries from Cinnamon custom-list:" >> "$STATUS_FILE"
    for ITEM in "${REMOVED_TTS_IDS[@]}"; do
        echo "  $ITEM" >> "$STATUS_FILE"
    done
fi

echo "" >> "$STATUS_FILE"
if [ "$CHOSEN_SCHEME" = "NONE" ]; then
    echo "Keyboard shortcut installation process finished." >> "$STATUS_FILE"
    echo "No TTS keyboard shortcuts are currently installed because both automatic shortcut sets had conflicts." >> "$STATUS_FILE"
    echo "TTS Voice Audition (to select voices and language) will still work from the desktop/menu launcher and terminal commands." >> "$STATUS_FILE"
else
    echo "Keyboard shortcuts are installed. If they do not respond immediately, open Keyboard → Shortcuts → Custom Shortcuts once, then close it." >> "$STATUS_FILE"
fi

echo ""
if [ "$CHOSEN_SCHEME" = "CTRL" ]; then
    echo "Shortcut set installed: Ctrl+Alt"
    echo "  Ctrl + Alt + Period (.)  — Start Speaking"
    echo "  Ctrl + Alt + Slash  (/)  — Pause / Resume"
    echo "  Ctrl + Alt + Comma  (,)  — Stop Speaking"
elif [ "$CHOSEN_SCHEME" = "SUPER" ]; then
    echo "Shortcut set installed: Super+Alt"
    echo "  Super + Alt + Period (.)  — Start Speaking"
    echo "  Super + Alt + Slash  (/)  — Pause / Resume"
    echo "  Super + Alt + Comma  (,)  — Stop Speaking"
else
    echo "No keyboard shortcuts were installed because both shortcut sets had conflicts."
    echo "See README.txt for manual shortcut setup guidance."
fi

echo ""
if [ "$CHOSEN_SCHEME" != "NONE" ]; then
    echo "Shortcut activation note:"
    echo "  The shortcuts have been created in Cinnamon."
    echo "  On tested Linux Mint systems, they usually work immediately."
    echo "  If they do not respond, open Keyboard → Shortcuts → Custom Shortcuts once, then close it."
    echo ""
    echo "To verify installation:"
    echo "  1. Copy text to the clipboard."
    echo "  2. Press the Start Speaking shortcut shown above."
    echo "  3. Use the Pause/Resume shortcut to pause/resume."
    echo "  4. Use the Stop Speaking shortcut to stop."
else
    echo "Shortcut activation note:"
    echo "  No TTS keyboard shortcuts are currently installed."
    echo "  See README.txt for manual shortcut setup guidance."
fi

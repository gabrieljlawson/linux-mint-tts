#!/bin/bash

# =============================================================================
# TTS Control Script
# toggle = pause/resume mpv playback
# stop   = hard-stop playback and clean up socket
# =============================================================================

export DISPLAY=${DISPLAY:-:0}
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"

SOCKET="/tmp/tts-clipboard-mpvsocket"
notify_user() {
    if command -v notify-send >/dev/null 2>&1; then
        notify-send "TTS" "$1" >/dev/null 2>&1 || true
    fi
}

case "$1" in
    toggle)
        if [ -S "$SOCKET" ]; then
            if command -v socat >/dev/null 2>&1; then
                echo '{ "command": ["cycle", "pause"] }' | socat - "$SOCKET" >/dev/null 2>&1
                notify_user "Toggle Pause/Resume"
            else
                notify_user "socat is not installed"
                exit 1
            fi
        else
            notify_user "No audio currently playing"
        fi
        ;;

    stop)
        # Hard kill audio/TTS processes used by this package.
        pkill -9 mpv >/dev/null 2>&1 || true
        pkill -9 -f "edge-tts" >/dev/null 2>&1 || true

        # Remove socket repeatedly in case mpv exits slightly after the first rm.
        rm -f "$SOCKET"
        sleep 0.2
        rm -f "$SOCKET"
        sleep 0.2
        rm -f "$SOCKET"

        notify_user "Narrator Stopped"
        ;;

    *)
        echo "Usage: $0 {toggle|stop}"
        exit 1
        ;;
esac

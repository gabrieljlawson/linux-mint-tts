TTS Voice Audition for Linux Mint
=================================
Version 1.0 Beta — Build 35

A clipboard-based text-to-speech tool for Linux Mint Cinnamon.

This tool reads text from the clipboard and speaks it using natural Microsoft Edge TTS voices. It works with Scrivener, web browsers, text editors, email, notes, and any application that can copy text to the clipboard.

Install
-------
Option 1 — Graphical method:

1. Right-click install.sh
2. Open Properties
3. Open Permissions
4. Enable "Allow executing file as program"
5. Close Properties
6. Double-click install.sh
7. Choose "Run in Terminal"

If install.sh opens in a text editor instead of running,
the file probably does not have Execute permission enabled yet.

Option 2 — Terminal method:

  chmod +x /path/to/TTS-Linux-Mint/install.sh
  bash /path/to/TTS-Linux-Mint/install.sh

Example if the package is in Downloads:

  chmod +x ~/Downloads/TTS-Linux-Mint/install.sh
  bash ~/Downloads/TTS-Linux-Mint/install.sh

The installer may show a pipx PATH warning during first install. This is normal. The installer handles setup. Opening a new terminal or logging in again refreshes PATH normally.

Contact
-------
Bug reports / feedback:
  gabrieljlawson@gmail.com

Internet Required
-----------------
Speech generation requires an active internet connection. If the internet is unavailable, clipboard speech will fail fast and show a notification.

System Components Installed or Used
-----------------------------------
The installer automatically installs or uses:

  yad       graphical windows
  mpv       audio playback
  socat     pause/resume/stop control
  xclip         X11 clipboard access
  xsel          alternate X11 clipboard access
  wl-clipboard  Wayland clipboard access through wl-paste
  pipx          installs edge-tts
  edge-tts      Microsoft cloud text-to-speech voices

The uninstaller does NOT remove these applications because they may be used by other programs.

Clipboard / Display Session Compatibility
-----------------------------------------
Build 35 supports multiple clipboard tools:

  wl-paste  Wayland clipboard access, installed by wl-clipboard
  xclip     X11 clipboard access
  xsel      alternate X11 clipboard access

Linux Mint TTS is primarily tested on Linux Mint Cinnamon. It should work in:

  Cinnamon Default session        normal Cinnamon session, commonly X11
  Cinnamon Software Rendering     fallback Cinnamon X11-style session
  Cinnamon Wayland session        uses wl-paste when available

Wayland and XWayland behavior can vary by application. Linux Mint TTS installs wl-clipboard, which provides wl-paste, but wl-paste only works when you are actually logged into a Wayland session. If your system falls back to X11, wl-paste may report that it cannot connect to a Wayland server; this is normal, and Linux Mint TTS should continue using xclip or xsel instead.

To check your current session type, run:

  echo $XDG_SESSION_TYPE
  echo $WAYLAND_DISPLAY

Expected results:

  X11 session:      x11, with WAYLAND_DISPLAY blank
  Wayland session:  wayland, with WAYLAND_DISPLAY usually wayland-0

The playback log shows which clipboard tool was used.

Desktop Launcher Trust Note
---------------------------
On some Linux Mint systems, the desktop launcher may initially show a gear icon or ask whether the launcher should be trusted.

If prompted, choose "Trust and Launch" or "Mark as Trusted." After trusting the launcher, the correct icon should appear and the desktop launcher should open normally.

Keyboard Shortcuts
------------------
The installer first tries to create this Ctrl + Alt shortcut set:

  Start Speaking:   Ctrl + Alt + Period (.)
  Pause / Resume:   Ctrl + Alt + Slash  (/)
  Stop Speaking:    Ctrl + Alt + Comma  (,)

If any Ctrl + Alt shortcut conflicts with an existing shortcut, the installer tries the full Super + Alt fallback set:

  Start Speaking:   Super + Alt + Period (.)
  Pause / Resume:   Super + Alt + Slash  (/)
  Stop Speaking:    Super + Alt + Comma  (,)

The Super key is usually the Windows key on PC keyboards.

The installer uses one complete shortcut set only. It does not mix Ctrl + Alt and Super + Alt shortcuts.

Keyboard shortcuts usually work immediately after install on tested Linux Mint systems. If they do not respond, open Menu → Preferences → Keyboard → Shortcuts → Custom Shortcuts once, then close it.

Keyboard Shortcut Conflicts
---------------------------
If both the Ctrl + Alt and Super + Alt shortcut sets conflict with existing shortcuts, no TTS shortcuts are installed automatically.

TTS Voice Audition (to select voices and language) will still work from:

  Desktop launcher
  Linux Mint menu entry
  Terminal commands

You can then create your own shortcuts manually.

Manual Shortcut Creation
------------------------
Open:

  Menu → Preferences → Keyboard → Shortcuts → Custom Shortcuts

Create shortcuts using these commands. Replace YOUR_USERNAME with your Linux username.

Start Speaking:

  /home/YOUR_USERNAME/Voices/speak_clipboard.sh

Pause / Resume:

  /home/YOUR_USERNAME/Voices/tts_control.sh toggle

Stop Speaking:

  /home/YOUR_USERNAME/Voices/tts_control.sh stop

Launch Voice Audition:

  /home/YOUR_USERNAME/Voices/audition_voices.sh

Find your username with:

  whoami

Verify Install / Troubleshooting
--------------------------------
Open Terminal and run:

  whoami

Copy some text to the clipboard.

Replace YOUR_USERNAME below with your username.

Test clipboard speech:

  /home/YOUR_USERNAME/Voices/speak_clipboard.sh

Test pause/resume while speech is playing:

  /home/YOUR_USERNAME/Voices/tts_control.sh toggle

Test stop while speech is playing:

  /home/YOUR_USERNAME/Voices/tts_control.sh stop

Test the voice audition window:

  /home/YOUR_USERNAME/Voices/audition_voices.sh

Test the installed keyboard shortcuts.

To see which clipboard tool was used during playback, run:

  cat ~/Voices/tts_playback.log

Look for a line such as:

  Clipboard tool: wl-paste
  Clipboard tool: xclip
  Clipboard tool: xsel

Voice Audition
--------------
Open TTS Voice Audition from the desktop icon or Linux Mint menu.

The audition window may stay open or be closed. Clipboard speech works independently of this window.

Voice Settings
--------------
Your selected voice settings are stored in:

  ~/Voices/*.conf

These settings are preserved when reinstalling or upgrading.

Logs
----
The installer writes the most recent install log to:

  ~/Voices/install.log

Clipboard playback writes one overwrite-only log to:

  ~/Voices/tts_playback.log

The tts_playback.log file is replaced each playback and does not accumulate numbered logs.

Uninstall
---------
To uninstall the TTS app, use either method below.

Method 1 — Linux Mint menu action:

  Right-click TTS Voice Audition in the Linux Mint menu.
  Choose: Uninstall TTS App

Important:
  Some Linux Mint menus may also show a generic option named "Uninstall".
  Do not use the generic "Uninstall" option. Use "Uninstall TTS App".

Method 2 — Terminal:

  bash ~/Voices/uninstall.sh

The uninstaller removes:

  ~/Voices
  desktop launcher
  Linux Mint menu entry
  TTS keyboard shortcuts
  TTS runtime socket

The uninstaller does NOT remove:

  yad
  mpv
  socat
  xclip
  xsel
  wl-clipboard
  pipx
  edge-tts

Those applications may be used by other software.


Uninstall safety note:
  The uninstaller removes TTS shortcuts only when the shortcut name and its exact command both match this package.
  It does not remove system packages such as yad, mpv, socat, xclip, xsel, wl-clipboard, pipx, or edge-tts.


Menu uninstall action:
On supported Linux Mint systems, right-clicking the TTS Voice Audition menu entry may show "Uninstall TTS App". This action runs ~/Voices/uninstall.sh in a terminal.

If your menu does not show "Uninstall TTS App", uninstall from Terminal with:

  bash /home/YOUR_USERNAME/Voices/uninstall.sh

#!/bin/bash

# =============================================================================
# TTS Linux Mint Voice Script Installer
# Creates ~/Voices, copies scripts, initializes configs, and creates desktop icon.
# =============================================================================

set -u
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VOICES_DIR="$HOME/Voices"
DEFAULT_VOICE="en-US-ChristopherNeural"
DEFAULT_LANG="en"

log() { echo "$1"; }

require_source_file() {
    local FILE="$1"
    if [ ! -f "$SCRIPT_DIR/$FILE" ]; then
        log "ERROR: Missing package file: $SCRIPT_DIR/$FILE"
        log "Make sure all package files are in the same TTS-Linux-Mint folder."
        exit 1
    fi
}

for f in speak_clipboard.sh tts_control.sh audition_voices.sh create_shortcuts.sh uninstall.sh; do
    require_source_file "$f"
done

EDGE_TTS_CMD=""
if command -v edge-tts >/dev/null 2>&1; then
    EDGE_TTS_CMD="$(command -v edge-tts)"
elif [ -x "$HOME/.local/bin/edge-tts" ]; then
    EDGE_TTS_CMD="$HOME/.local/bin/edge-tts"
else
    log "ERROR: edge-tts not found. Run install_apps.sh first."
    exit 1
fi

log "Creating install directory: $VOICES_DIR"
mkdir -p "$VOICES_DIR"

log "Copying scripts into $VOICES_DIR..."
cp "$SCRIPT_DIR/speak_clipboard.sh" "$VOICES_DIR/"
cp "$SCRIPT_DIR/tts_control.sh" "$VOICES_DIR/"
cp "$SCRIPT_DIR/audition_voices.sh" "$VOICES_DIR/"
cp "$SCRIPT_DIR/create_shortcuts.sh" "$VOICES_DIR/"
cp "$SCRIPT_DIR/uninstall.sh" "$VOICES_DIR/"
if [ -f "$SCRIPT_DIR/README.txt" ]; then
    cp "$SCRIPT_DIR/README.txt" "$VOICES_DIR/"
    log "README copied to $VOICES_DIR/README.txt."
fi
chmod +x "$VOICES_DIR"/*.sh
log "Permissions set for all scripts in $VOICES_DIR."

log "Checking voice configuration files..."
VOICE_NUM=$(
    "$EDGE_TTS_CMD" --list-voices 2>/dev/null |
    awk '{print $1}' |
    grep -E '^en-[A-Z]{2,3}-[a-zA-Z]+Neural$' |
    sort -u |
    nl -w1 -s'. ' |
    grep "$DEFAULT_VOICE" |
    awk -F'. ' '{print $1}' |
    head -1
)
if [ -z "${VOICE_NUM:-}" ]; then
    VOICE_NUM=""
fi

create_config_if_missing_or_blank() {
    local FILE="$1"
    local VALUE="$2"
    local LABEL="$3"

    if [ ! -s "$FILE" ]; then
        echo "$VALUE" > "$FILE"
        log "Created default config: $LABEL"
    else
        log "Preserved existing config: $LABEL"
    fi
}

create_config_if_missing_or_blank "$VOICES_DIR/tts_default_voice.conf" "$DEFAULT_VOICE" "tts_default_voice.conf"
create_config_if_missing_or_blank "$VOICES_DIR/tts_default_voice_num.conf" "$VOICE_NUM" "tts_default_voice_num.conf"
create_config_if_missing_or_blank "$VOICES_DIR/tts_last_auditioned.conf" "$DEFAULT_VOICE" "tts_last_auditioned.conf"
create_config_if_missing_or_blank "$VOICES_DIR/tts_last_auditioned_num.conf" "$VOICE_NUM" "tts_last_auditioned_num.conf"
create_config_if_missing_or_blank "$VOICES_DIR/tts_last_language.conf" "$DEFAULT_LANG" "tts_last_language.conf"

log "Default language if new install: English ($DEFAULT_LANG)"
log "Default voice if new install:    $DEFAULT_VOICE"
if [ -n "$VOICE_NUM" ]; then
    log "Default voice # if new install:  $VOICE_NUM"
else
    log "Default voice # if new install:  not calculated"
fi

log "Creating desktop launcher..."
DESKTOP_DIR="$HOME/Desktop"
DESKTOP_FILE="$DESKTOP_DIR/TTS Voice Audition.desktop"
mkdir -p "$DESKTOP_DIR"
cat > "$DESKTOP_FILE" <<EOF_DESKTOP
[Desktop Entry]
Type=Application
Name=TTS Voice Audition
Comment=Choose and test TTS voices
Exec=$VOICES_DIR/audition_voices.sh
Icon=preferences-desktop-sound
Terminal=false
Categories=AudioVideo;Audio;Utility;
Actions=Uninstall;

[Desktop Action Uninstall]
Name=Uninstall TTS App
Icon=edit-delete
Exec=x-terminal-emulator -e $VOICES_DIR/uninstall.sh
EOF_DESKTOP
chmod +x "$DESKTOP_FILE"
if command -v gio >/dev/null 2>&1; then
    gio set "$DESKTOP_FILE" metadata::trusted true >/dev/null 2>&1 || true
fi
log "Desktop launcher created: $DESKTOP_FILE"
log "If Linux Mint asks, right-click the icon and choose Allow Launching."

log "Creating Linux Mint menu entry..."
APP_DIR="$HOME/.local/share/applications"
MENU_FILE="$APP_DIR/tts-voice-audition.desktop"
mkdir -p "$APP_DIR"
cat > "$MENU_FILE" <<EOF_MENU
[Desktop Entry]
Type=Application
Name=TTS Voice Audition
Comment=Choose and test TTS voices
Exec=$VOICES_DIR/audition_voices.sh
Icon=preferences-desktop-sound
Terminal=false
Categories=AudioVideo;Audio;Utility;
Keywords=TTS;Text to Speech;Voice;Audio;Speech;
Actions=Uninstall;

[Desktop Action Uninstall]
Name=Uninstall TTS App
Icon=edit-delete
Exec=x-terminal-emulator -e $VOICES_DIR/uninstall.sh
EOF_MENU
chmod +x "$MENU_FILE"
log "Menu entry created: $MENU_FILE"
log "Menu category: Sound & Video / Audio / Utility, depending on Linux Mint menu layout."

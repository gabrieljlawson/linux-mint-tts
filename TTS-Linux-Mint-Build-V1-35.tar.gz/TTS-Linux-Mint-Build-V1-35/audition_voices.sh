#!/bin/bash

# =============================================================================
# TTS Voice Audition Script
# Compatible with YAD 0.40.0
# Fixes: corrected language codes (el/nb), default voice number, PID tracking
# =============================================================================

# --- Ensure correct paths ---
export DISPLAY=${DISPLAY:-:0}
USERNAME=$(whoami)
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"
APP_VERSION="1.0 Beta — Build 35"

# --- PID file for kill/restart support ---
PID_FILE="/tmp/tts_audition.pid"
echo $$ > "$PID_FILE"
trap "rm -f $PID_FILE" EXIT

# --- Files ---
CONFIG_FILE="$HOME/Voices/tts_default_voice.conf"
CONFIG_NUM_FILE="$HOME/Voices/tts_default_voice_num.conf"
LAST_VOICE_FILE="$HOME/Voices/tts_last_auditioned.conf"
LAST_VOICE_NUM_FILE="$HOME/Voices/tts_last_auditioned_num.conf"
LANG_FILE="$HOME/Voices/tts_last_language.conf"

# --- Gothic prose test text ---
TEST_TEXT="The shadow in the hallway wasn't his own, yet it moved with his every step."

# --- Language list: "Name (code)" format ---
# Codes verified against edge-tts locale prefixes
LANG_LIST=(
    "Arabic (ar)"
    "Chinese (zh)"
    "Danish (da)"
    "Dutch (nl)"
    "English (en)"
    "Finnish (fi)"
    "French (fr)"
    "German (de)"
    "Greek (el)"
    "Hindi (hi)"
    "Italian (it)"
    "Japanese (ja)"
    "Korean (ko)"
    "Norwegian (nb)"
    "Polish (pl)"
    "Portuguese (pt)"
    "Russian (ru)"
    "Spanish (es)"
    "Swedish (sv)"
    "Turkish (tr)"
)

# --- Extract code from "Name (code)" display string ---
extract_code() {
    echo "$1" | grep -o '([a-z]*)' | tr -d '()'
}

# --- Language Code to Full Name Lookup ---
get_language_name() {
    case "$1" in
        en) echo "English" ;;
        fr) echo "French" ;;
        es) echo "Spanish" ;;
        de) echo "German" ;;
        it) echo "Italian" ;;
        pt) echo "Portuguese" ;;
        nl) echo "Dutch" ;;
        ru) echo "Russian" ;;
        zh) echo "Chinese" ;;
        ja) echo "Japanese" ;;
        ar) echo "Arabic" ;;
        ko) echo "Korean" ;;
        el) echo "Greek" ;;
        pl) echo "Polish" ;;
        sv) echo "Swedish" ;;
        nb) echo "Norwegian" ;;
        da) echo "Danish" ;;
        fi) echo "Finnish" ;;
        tr) echo "Turkish" ;;
        hi) echo "Hindi" ;;
        *)  echo "$1" ;;
    esac
}

# --- Read current default voice ---
get_default_voice() {
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "Not set"
    fi
}

# --- Read current default voice number ---
get_default_voice_num() {
    if [ -f "$CONFIG_NUM_FILE" ]; then
        cat "$CONFIG_NUM_FILE"
    else
        echo ""
    fi
}

# --- Read last language used ---
get_last_language() {
    local LANG
    if [ -f "$LANG_FILE" ]; then
        LANG=$(cat "$LANG_FILE" | xargs)
    else
        LANG="en"
    fi

    # First-run safety: default to English if the saved value is missing or malformed
    if ! echo "$LANG" | grep -Eq '^[a-z]{2}$'; then
        LANG="en"
        echo "en" > "$LANG_FILE"
    fi

    echo "$LANG"
}

# --- Read last auditioned voice ---
get_last_voice() {
    if [ -f "$LAST_VOICE_FILE" ]; then
        cat "$LAST_VOICE_FILE"
    else
        echo ""
    fi
}

# --- Read last auditioned voice number ---
get_last_voice_num() {
    if [ -f "$LAST_VOICE_NUM_FILE" ]; then
        cat "$LAST_VOICE_NUM_FILE"
    else
        echo ""
    fi
}

# --- Strip number prefix from display entry to get clean voice name ---
strip_number() {
    echo "$1" | sed 's/^[0-9]*\. //'
}

# --- Save default voice ---
# Config file is the single source of truth for the default voice
# speak_clipboard.sh reads this file at runtime - no direct editing needed
save_default_voice() {
    local VOICE="$1"
    local VOICE_NUM="$2"
    echo "$VOICE" > "$CONFIG_FILE"
    echo "$VOICE_NUM" > "$CONFIG_NUM_FILE"
}

# --- Kill any playing audio ---
stop_audio() {
    killall -q mpv 2>/dev/null
    sleep 0.1
}

# --- Check internet connectivity ---
check_internet() {
    if ! ping -c 1 -W 3 8.8.8.8 &>/dev/null; then
        yad --title="No Internet Connection" --image="dialog-error" \
            --text="Cannot connect to the internet.\n\nThe TTS service requires an internet connection.\nPlease check your connection and try again." \
            --button="OK:0" --center --width=400
        return 1
    fi
    return 0
}

# --- Validate a language code against edge-tts ---
validate_language() {
    local CODE="$1"
    edge-tts --list-voices 2>/dev/null | awk '{print $1}' | grep -E "^${CODE}-[A-Z]{2,3}-[a-zA-Z]+Neural$" | sort | uniq | head -1
}

# --- Confirm and switch to a new language ---
confirm_language_switch() {
    local NEW_LANG="$1"
    local CURRENT_LANG="$2"

    if ! check_internet; then
        echo "$CURRENT_LANG"
        return
    fi

    TEST_RESULT=$(validate_language "$NEW_LANG")
    if [ -z "$TEST_RESULT" ]; then
        yad --title="Invalid Language Code" --image="dialog-error" \
            --text="No voices found for: <b>$NEW_LANG</b>\n\nPlease try a different language code." \
            --button="OK:0" --center --width=350
        echo "$CURRENT_LANG"
        return
    fi

    NEW_LANG_NAME=$(get_language_name "$NEW_LANG")
    yad --title="Change Language" --image="dialog-question" \
        --text="Change language to <b>$NEW_LANG_NAME</b> ($NEW_LANG)?" \
        --button="Cancel:1" --button="Yes, Switch:0" --center --width=320
    if [ $? -eq 0 ]; then
        echo "$NEW_LANG" > "$LANG_FILE"
        echo "$NEW_LANG"
    else
        echo "$CURRENT_LANG"
    fi
}

# --- Play a voice and save as Last Played ---
play_voice() {
    local VOICE="$1"
    local VOICE_NUM="$2"

    if ! check_internet; then
        return 1
    fi

    stop_audio
    echo "$VOICE" > "$LAST_VOICE_FILE"
    echo "$VOICE_NUM" > "$LAST_VOICE_NUM_FILE"
    edge-tts --voice "$VOICE" --text "Voice $VOICE_NUM. $TEST_TEXT" --write-media - 2>/dev/null | mpv - --no-video --msg-level=all=no &
    sleep 0.5
}

# --- Play default voice WITHOUT changing Last Played ---
play_default_voice() {
    local DEFAULT_VOICE
    DEFAULT_VOICE=$(get_default_voice)

    if [ "$DEFAULT_VOICE" = "Not set" ] || [ -z "$DEFAULT_VOICE" ]; then
        yad --title="Play Default" --image="dialog-warning" \
            --text="No default voice has been set yet.\nDouble-click a voice and click Set Default first." \
            --button="OK:0" --center --width=380
        return
    fi

    if ! check_internet; then
        return
    fi

    # Save current Last Played before playing default
    SAVED_LAST_VOICE=$(get_last_voice)
    SAVED_LAST_VOICE_NUM=$(get_last_voice_num)
    DEFAULT_VOICE_NUM=$(get_default_voice_num)

    if [ -n "$DEFAULT_VOICE_NUM" ]; then
        SPOKEN_TEXT="Voice $DEFAULT_VOICE_NUM. $TEST_TEXT"
    else
        SPOKEN_TEXT="$TEST_TEXT"
    fi

    stop_audio
    edge-tts --voice "$DEFAULT_VOICE" --text "$SPOKEN_TEXT" --write-media - 2>/dev/null | mpv - --no-video --msg-level=all=no &
    sleep 0.5

    # Restore Last Played
    if [ -n "$SAVED_LAST_VOICE" ]; then
        echo "$SAVED_LAST_VOICE" > "$LAST_VOICE_FILE"
        echo "$SAVED_LAST_VOICE_NUM" > "$LAST_VOICE_NUM_FILE"
    fi
}

# =============================================================================
# HELP SCREEN
# =============================================================================
show_help() {
    HELP_FILE=$(mktemp /tmp/tts_help_XXXX.txt)
    cat > "$HELP_FILE" << 'HELPTEXT'
── QUICK START ──

1. Copy text to the clipboard.

2. Press your installed shortcut keys:

   Ctrl + Alt + Period (.)  → Start Speaking
   Ctrl + Alt + Slash  (/)  → Pause / Resume
   Ctrl + Alt + Comma  (,)  → Stop Speaking

   If shortcut conflicts occurred during install,
   the following may have been installed instead:

   Super + Alt + Period (.) → Start Speaking
   Super + Alt + Slash  (/) → Pause / Resume
   Super + Alt + Comma  (,) → Stop Speaking

   Super = Windows key

   See README.txt for additional shortcut information.

3. Use TTS Voice Audition to:
   - choose language
   - preview voices
   - set your default voice

── MAIN SCREEN ──

Choose Language
  Opens the language chooser window.
  Double-click a language from the list to select it.
  You can also single-click a language, then click OK.
  Or click Manual Entry to type a code for unlisted languages.
  The language is validated and confirmed before switching.

Pick a Voice
  Opens the voice browser for the current language.
  Lets you audition and set your default voice.

Help
  Shows this help screen.

Exit
  Closes the TTS Voice Audition tool.

── PICK A VOICE SCREEN ──

Voice List
  Shows all available voices numbered for easy tracking.
  The number matches what is announced when the voice plays.
  Double-click any voice to play it immediately.

Stop
  Stops the currently playing voice immediately.

Next Voice
  Stops current voice, advances to the next voice in the
  list, and plays it automatically.
  Useful after playing voice 32 to quickly move to voice 33
  without scrolling the list.

Play Default
  Plays your current default voice for comparison.
  Does NOT change the Last Played voice — your place is preserved.
  Useful when deciding if a new voice is better than your current default.

Set Default
  Sets the LAST PLAYED voice as your default TTS voice.
  Double-click a voice first, or use Next Voice, to hear a voice.
  Then click Set Default.
  Note: "Play Default" does not affect "Set Default."
  "Set Default" uses the last voice played by double-clicking
  a voice or by using Next Voice.

Back
  Returns to the Main Screen. Stops any playing audio.

Exit
  Closes everything. Stops any playing audio.

── INTERNET CONNECTION ──

This tool requires an active internet connection to generate
speech. The Microsoft Azure TTS service is used for all
voice playback. If you lose connectivity during use, you
will see an error message prompting you to check your
connection before trying again.

── SYSTEM REQUIREMENTS ──

This tool uses these installed system components:
  yad      — graphical windows
  mpv      — audio playback
  socat    — pause/resume/stop control
  xclip        — X11 clipboard access
  xsel         — alternate X11 clipboard access
  wl-clipboard — Wayland clipboard access through wl-paste
  pipx         — installs edge-tts
  edge-tts     — Microsoft cloud text-to-speech voices

The installer checks and installs these components automatically.
Clipboard support tries wl-paste, then xclip, then xsel.
Cinnamon Software Rendering behaves like an X11-style session.
Wayland support depends on actually running a Wayland session.
If wl-paste cannot connect to a Wayland server,
the tool falls back to xclip or xsel.
To check your installed YAD version run: yad --version

── KEYBOARD SHORTCUTS ──

These shortcuts work system-wide while text is in your clipboard:

  Start Speaking   —  Ctrl + Alt + Period  (.)
  Pause / Resume   —  Ctrl + Alt + Slash   (/)
  Stop Speaking    —  Ctrl + Alt + Comma   (,)

The comma and period keys are the unshifted versions of < and >,
which makes them natural back/forward-style controls while writing:
  Comma  (,)  Stop          — index finger
  Period (.)  Start         — middle finger
  Slash  (/)  Pause/Resume  — ring finger

Alternate shortcut option:
  If the Ctrl + Alt shortcut set conflicts with your system or another
  application, the installer will try the alternate Super + Alt shortcut set.
  The Super key is usually the Windows key on PC keyboards.
  See the README for details and troubleshooting.

The audition window may stay open or be closed. Clipboard speech works
independently of this window.

To change shortcuts go to:
  Menu → Preferences → Keyboard → Shortcuts → Custom Shortcuts

For uninstall instructions, additional shortcut options, troubleshooting,
and advanced configuration, see the README file included with this package.

If your menu shows both "Uninstall" and "Uninstall TTS App", use
"Uninstall TTS App" for this package.
HELPTEXT

    yad --title="TTS Voice Audition — Help" \
        --text-info \
        --filename="$HELP_FILE" \
        --button="Close:0" \
        --center --width=680 --height=540

    rm -f "$HELP_FILE"
}


# =============================================================================
# ABOUT SCREEN
# =============================================================================
show_about() {
    yad --title="About TTS Voice Audition" \
        --image="audio-speakers" \
        --text="<b>TTS Voice Audition</b>\nVersion: $APP_VERSION\n\nClipboard-based text-to-speech for Linux Mint Cinnamon.\n\nUses edge-tts for natural Microsoft cloud voices and mpv for playback.\n\nRequires an internet connection for speech generation.\n\nSee README for help and troubleshooting." \
        --button="OK:0" \
        --center --width=460
}

# =============================================================================
# CHOOSE LANGUAGE SCREEN — Window 1: Language List
# =============================================================================
choose_language() {
    local CURRENT_LANG="$1"
    local CURRENT_LANG_NAME
    CURRENT_LANG_NAME=$(get_language_name "$CURRENT_LANG")

    while true; do
        PICKED=$(yad --title="Choose Language" \
            --text="<b>Current Language:</b> $CURRENT_LANG_NAME ($CURRENT_LANG)\n\n<span foreground='blue'><b><big>⬇  Double-click a language below to select it  ⬇</big></b></span>\nTo use a language not shown here, click Manual Entry below." \
            --list \
            --column="Available Languages" \
            --print-column=1 \
            "${LANG_LIST[@]}" \
            --button="Cancel:1" \
            --button="Manual Entry:2" \
            --button="OK:0" \
            --center --width=380 --height=500 --on-top)
        RESPONSE=$?

        case $RESPONSE in
            0)  # OK or double-click
                SELECTED=$(echo "$PICKED" | tr -d '|' | xargs)
                if [ -z "$SELECTED" ]; then
                    yad --title="Choose Language" --image="dialog-warning" \
                        --text="Please double-click a language to select it." \
                        --button="OK:0" --center --width=350
                    continue
                fi
                NEW_LANG=$(extract_code "$SELECTED")
                RESULT=$(confirm_language_switch "$NEW_LANG" "$CURRENT_LANG")
                echo "$RESULT"
                return
                ;;

            2)  # Manual Entry — Window 2
                MANUAL=$(yad --title="Manual Language Entry" \
                    --text="Enter a language code for a language not shown in the list.\n\nExamples: en, fr, es, de, zh, ja, ar, ko\n" \
                    --entry --entry-label="Language Code:" \
                    --button="Cancel:1" --button="OK:0" \
                    --center --width=380)
                MANUAL_RESPONSE=$?

                if [ "$MANUAL_RESPONSE" -eq 0 ] && [ -n "$MANUAL" ]; then
                    MANUAL=$(echo "$MANUAL" | xargs)
                    RESULT=$(confirm_language_switch "$MANUAL" "$CURRENT_LANG")
                    echo "$RESULT"
                    return
                fi
                ;;

            1|252)  # Cancel
                echo "$CURRENT_LANG"
                return
                ;;
        esac
    done
}

# =============================================================================
# PICK A VOICE SCREEN
# =============================================================================
pick_a_voice() {
    local LANG_CODE="$1"
    local LANG_NAME
    LANG_NAME=$(get_language_name "$LANG_CODE")

    if ! check_internet; then
        return
    fi

    # Get clean list of voices
    mapfile -t VOICES < <(edge-tts --list-voices 2>/dev/null | awk '{print $1}' | grep -E "^${LANG_CODE}-[A-Z]{2,3}-[a-zA-Z]+Neural$" | sort | uniq)

    if [ "${#VOICES[@]}" -eq 0 ]; then
        yad --title="TTS Voice Audition" --image="dialog-error" \
            --text="No voices found for <b>$LANG_NAME</b>.\n\nPlease choose a different language." \
            --button="OK:0" --center --width=350
        return
    fi

    TOTAL="${#VOICES[@]}"

    # Build numbered display entries
    DISPLAY_VOICES=()
    for i in "${!VOICES[@]}"; do
        NUM=$((i + 1))
        DISPLAY_VOICES+=("$NUM. ${VOICES[$i]}")
    done

    # CURRENT_INDEX starts at -1 for fresh language
    # If last voice matches a voice in this language resume from there
    LAST_VOICE=$(get_last_voice)
    CURRENT_INDEX=-1
    if [ -n "$LAST_VOICE" ]; then
        for i in "${!VOICES[@]}"; do
            if [ "${VOICES[$i]}" = "$LAST_VOICE" ]; then
                CURRENT_INDEX=$i
                break
            fi
        done
    fi

    while true; do
        # Read fresh display values
        DEFAULT_VOICE=$(get_default_voice)
        DEFAULT_VOICE_NUM=$(get_default_voice_num)
        LAST_VOICE_NUM=$(get_last_voice_num)
        LAST_VOICE=$(get_last_voice)

        # Format default voice display with number if available
        if [ -n "$DEFAULT_VOICE_NUM" ] && [ "$DEFAULT_VOICE" != "Not set" ]; then
            DEFAULT_DISPLAY="Voice $DEFAULT_VOICE_NUM — $DEFAULT_VOICE"
        else
            DEFAULT_DISPLAY="$DEFAULT_VOICE"
        fi

        # Format last played
        if [ -n "$LAST_VOICE" ] && [ -n "$LAST_VOICE_NUM" ]; then
            LAST_PLAYED_DISPLAY="Voice $LAST_VOICE_NUM — $LAST_VOICE"
        else
            LAST_PLAYED_DISPLAY="None"
        fi

        DISPLAY_TEXT="<b>Language:</b> $LANG_NAME ($LANG_CODE)     <b>Total:</b> $TOTAL voices\n<b>Default:</b> $DEFAULT_DISPLAY\n<b>Last Played:</b> $LAST_PLAYED_DISPLAY\n\n<span foreground='blue'><b><big>⬇  Double-click a voice below to play it  ⬇</big></b></span>\n<b>Set Default will use the Last Played voice shown above</b>"

        PICKED=$(yad --title="Pick a Voice" \
            --text="$DISPLAY_TEXT" \
            --list \
            --column="Available Voices" \
            --print-column=1 \
            "${DISPLAY_VOICES[@]}" \
            --button="Stop:2" \
            --button="Next Voice:3" \
            --button="Play Default:4" \
            --button="Set Default:5" \
            --button="Back:6" \
            --button="Exit:7" \
            --center --width=480 --height=540 --on-top)
        RESPONSE=$?

        # Extract selected display entry and strip number prefix
        SELECTED_DISPLAY=$(echo "$PICKED" | tr -d '|' | xargs)
        SELECTED_VOICE=$(strip_number "$SELECTED_DISPLAY")

        # If user double-clicked update CURRENT_INDEX
        if [ -n "$SELECTED_VOICE" ] && [ "$RESPONSE" -eq 0 ]; then
            for i in "${!VOICES[@]}"; do
                if [ "${VOICES[$i]}" = "$SELECTED_VOICE" ]; then
                    CURRENT_INDEX=$i
                    break
                fi
            done
        fi

        case $RESPONSE in
            0)  # Double-click — play selected voice
                if [ -n "$SELECTED_VOICE" ]; then
                    VOICE_NUM=$((CURRENT_INDEX + 1))
                    play_voice "$SELECTED_VOICE" "$VOICE_NUM"
                fi
                ;;

            2)  # Stop
                stop_audio
                ;;

            3)  # Next Voice
                stop_audio
                if [ "$CURRENT_INDEX" -lt "$((TOTAL - 1))" ]; then
                    CURRENT_INDEX=$((CURRENT_INDEX + 1))
                    CURRENT_VOICE="${VOICES[$CURRENT_INDEX]}"
                    VOICE_NUM=$((CURRENT_INDEX + 1))
                    play_voice "$CURRENT_VOICE" "$VOICE_NUM"
                else
                    yad --title="End of List" --image="dialog-information" \
                        --text="You have reached the last voice in the list." \
                        --button="OK:0" --center --width=350
                fi
                ;;

            4)  # Play Default
                play_default_voice
                ;;

            5)  # Set Default
                LV=$(get_last_voice)
                LV_NUM=$(get_last_voice_num)
                if [ -n "$LV" ]; then
                    yad --title="Set Default Voice" --image="dialog-question" \
                        --text="Set default voice to:\n<b>$LV</b>\n(Voice $LV_NUM)?" \
                        --button="Cancel:1" --button="OK:0" --center --width=420
                    if [ $? -eq 0 ]; then
                        save_default_voice "$LV" "$LV_NUM"
                        yad --title="Set Default Voice" --image="dialog-information" \
                            --text="Default voice has been set to:\n<b>$LV</b>\n(Voice $LV_NUM)" \
                            --button="OK:0" --center --width=420
                    fi
                else
                    yad --title="Set Default" --image="dialog-warning" \
                        --text="No voice has been played yet.\nPlease double-click a voice to play it first,\nthen click Set Default." \
                        --button="OK:0" --center --width=380
                fi
                ;;

            6)  # Back
                stop_audio
                return
                ;;

            7|252)  # Exit
                stop_audio
                exit 0
                ;;
        esac
    done
}

# =============================================================================
# MAIN SCREEN
# =============================================================================
main_screen() {
    CURRENT_LANG=$(get_last_language)

    while true; do
        DEFAULT_VOICE=$(get_default_voice)
        DEFAULT_VOICE_NUM=$(get_default_voice_num)
        LANG_NAME=$(get_language_name "$CURRENT_LANG")

        # Format default display with number if available
        if [ -n "$DEFAULT_VOICE_NUM" ] && [ "$DEFAULT_VOICE" != "Not set" ]; then
            DEFAULT_DISPLAY="Voice $DEFAULT_VOICE_NUM — $DEFAULT_VOICE"
        else
            DEFAULT_DISPLAY="$DEFAULT_VOICE"
        fi

        yad --title="TTS Voice Audition" \
            --text="<b>Current Language:</b> $LANG_NAME ($CURRENT_LANG)\n<b>Current Default Voice:</b> $DEFAULT_DISPLAY" \
            --button="Choose Language:0" \
            --button="Pick a Voice:1" \
            --button="Help:2" \
            --button="About:3" \
            --button="Exit:4" \
            --center --width=520 --height=160 --on-top
        RESPONSE=$?

        case $RESPONSE in
            0)  # Choose Language
                NEW_LANG=$(choose_language "$CURRENT_LANG")
                if [ -n "$NEW_LANG" ]; then
                    CURRENT_LANG="$NEW_LANG"
                fi
                ;;

            1)  # Pick a Voice
                pick_a_voice "$CURRENT_LANG"
                ;;

            2)  # Help
                show_help
                ;;

            3)  # About
                show_about
                ;;

            4|252)  # Exit
                stop_audio
                exit 0
                ;;
        esac
    done
}

# --- Entry point ---
main_screen

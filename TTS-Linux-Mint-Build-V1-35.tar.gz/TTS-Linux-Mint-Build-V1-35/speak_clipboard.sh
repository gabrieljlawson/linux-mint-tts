#!/bin/bash

# =============================================================================
# Speak Clipboard Script
# Reads clipboard text and speaks it using edge-tts + mpv.
# Runs playback in the background so the terminal is not locked.
# =============================================================================

export DISPLAY=${DISPLAY:-:0}
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"

VOICES_DIR="$HOME/Voices"
CONFIG="$VOICES_DIR/tts_default_voice.conf"
SOCKET="/tmp/tts-clipboard-mpvsocket"
LOG_FILE="$VOICES_DIR/tts_playback.log"
DEFAULT_VOICE="en-US-ChristopherNeural"

mkdir -p "$VOICES_DIR"
: > "$LOG_FILE"

notify_user() {
    if command -v notify-send >/dev/null 2>&1; then
        notify-send "TTS" "$1" >/dev/null 2>&1 || true
    fi
}

# Clipboard helper. Prefer Wayland-native wl-paste when available, then X11 tools.
get_clipboard_text() {
    local text=""

    if command -v wl-paste >/dev/null 2>&1; then
        text=$(timeout 2s wl-paste --no-newline 2>/dev/null || true)
        if [ -n "$text" ]; then
            printf '%s' "$text"
            echo "Clipboard tool: wl-paste" >> "$LOG_FILE"
            return 0
        fi
    fi

    if command -v xclip >/dev/null 2>&1; then
        text=$(timeout 2s xclip -selection clipboard -o 2>/dev/null || true)
        if [ -n "$text" ]; then
            printf '%s' "$text"
            echo "Clipboard tool: xclip" >> "$LOG_FILE"
            return 0
        fi
    fi

    if command -v xsel >/dev/null 2>&1; then
        text=$(timeout 2s xsel --clipboard --output 2>/dev/null || true)
        if [ -n "$text" ]; then
            printf '%s' "$text"
            echo "Clipboard tool: xsel" >> "$LOG_FILE"
            return 0
        fi
    fi

    return 1
}

# Required tools
if ! command -v wl-paste >/dev/null 2>&1 && ! command -v xclip >/dev/null 2>&1 && ! command -v xsel >/dev/null 2>&1; then
    notify_user "No supported clipboard tool found"
    echo "ERROR: No supported clipboard tool found. Install wl-clipboard, xclip, or xsel." >> "$LOG_FILE"
    exit 1
fi

if ! command -v edge-tts >/dev/null 2>&1; then
    notify_user "edge-tts was not found"
    echo "ERROR: edge-tts was not found" >> "$LOG_FILE"
    exit 1
fi

if ! command -v mpv >/dev/null 2>&1; then
    notify_user "mpv is not installed"
    echo "ERROR: mpv is not installed" >> "$LOG_FILE"
    exit 1
fi

# Fail fast when offline. edge-tts is a cloud service, so speech cannot start without internet.
if ! ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
    notify_user "No internet connection"
    echo "ERROR: No internet connection detected" >> "$LOG_FILE"
    exit 1
fi

# Grab text from clipboard
TEXT=$(get_clipboard_text || true)

if [ -z "$TEXT" ]; then
    notify_user "Clipboard is empty"
    echo "ERROR: Clipboard is empty" >> "$LOG_FILE"
    exit 1
fi

# Read default voice from config, with fallback if missing or blank
VOICE="$DEFAULT_VOICE"
if [ -f "$CONFIG" ]; then
    CONFIG_VOICE=$(cat "$CONFIG" | xargs)
    if [ -n "$CONFIG_VOICE" ]; then
        VOICE="$CONFIG_VOICE"
    else
        echo "$DEFAULT_VOICE" > "$CONFIG"
    fi
else
    echo "$DEFAULT_VOICE" > "$CONFIG"
fi

# Stop any previous playback quietly and remove stale socket
pkill -9 mpv >/dev/null 2>&1 || true
pkill -9 -f "edge-tts" >/dev/null 2>&1 || true
rm -f "$SOCKET"
sleep 0.1

# Run playback in background so terminal/shortcut returns immediately.
# The socket is cleaned up when playback naturally finishes or is stopped.
(
    echo "Starting TTS playback at $(date)" >> "$LOG_FILE"
    echo "Voice: $VOICE" >> "$LOG_FILE"

    edge-tts --voice "$VOICE" --text "$TEXT" --write-media - 2>>"$LOG_FILE" \
        | mpv - --no-video --no-terminal --input-ipc-server="$SOCKET" >>"$LOG_FILE" 2>&1

    PIPE_STATUS=("${PIPESTATUS[@]}")
    rm -f "$SOCKET"

    # PIPE_STATUS[0] is edge-tts, PIPE_STATUS[1] is mpv.
    # Nonzero is expected if user presses Stop, so only log it.
    echo "Playback ended at $(date). edge-tts=${PIPE_STATUS[0]} mpv=${PIPE_STATUS[1]}" >> "$LOG_FILE"
) >/dev/null 2>&1 &

disown
exit 0

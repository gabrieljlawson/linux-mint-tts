#!/bin/bash

# =============================================================================
# Linux Mint TTS Installer
# Version 1.0 Beta — Build 35
#
# IMPORTANT — GRAPHICAL INSTALL
#
# Before double-clicking this installer:
#
# 1. Right-click install.sh
# 2. Choose Properties → Permissions
# 3. Enable "Allow executing file as program"
# 4. Close Properties
# 5. Double-click install.sh
# 6. Choose "Run in Terminal"
#
# If you are seeing this text in a text editor, install.sh is probably
# not marked executable yet. Set Execute permission first, then run again.
#
# TERMINAL INSTALL
#
#   chmod +x /path/to/TTS-Linux-Mint/install.sh
#   bash /path/to/TTS-Linux-Mint/install.sh
#
# Example:
#
#   chmod +x ~/Downloads/TTS-Linux-Mint/install.sh
#   bash ~/Downloads/TTS-Linux-Mint/install.sh
# =============================================================================

set -u
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_FILE="/tmp/tts_linux_mint_install.log"
VOICES_DIR="$HOME/Voices"

: > "$LOG_FILE"

log() {
    echo "$1" | tee -a "$LOG_FILE"
}

require_file() {
    local FILE="$1"
    if [ ! -f "$SCRIPT_DIR/$FILE" ]; then
        log "ERROR: Missing package file: $SCRIPT_DIR/$FILE"
        log "Make sure all package files are in the same TTS-Linux-Mint folder."
        exit 1
    fi
}

run_step() {
    local LABEL="$1"
    local FILE="$2"

    log ""
    log "============================================================"
    log "$LABEL"
    log "============================================================"

    bash "$SCRIPT_DIR/$FILE" 2>&1 | tee -a "$LOG_FILE"
    local STATUS=${PIPESTATUS[0]}

    if [ "$STATUS" -ne 0 ]; then
        log "ERROR: $LABEL failed."
        log "Install log: $LOG_FILE"
        if [ -d "$VOICES_DIR" ]; then
            cp "$LOG_FILE" "$VOICES_DIR/install.log" 2>/dev/null || true
        fi
        exit "$STATUS"
    fi
}

log "============================================================"
log "TTS Linux Mint Installer — Version 1.0 Beta Build 35"
log "============================================================"
log "Package folder: $SCRIPT_DIR"
log "Install target:  $VOICES_DIR"

for f in install_apps.sh install_voices.sh create_shortcuts.sh speak_clipboard.sh tts_control.sh audition_voices.sh uninstall.sh README.txt; do
    require_file "$f"
done

run_step "Step 1 of 3: Install required apps" "install_apps.sh"
run_step "Step 2 of 3: Install TTS voice scripts" "install_voices.sh"
run_step "Step 3 of 3: Create keyboard shortcuts" "create_shortcuts.sh"

if [ -d "$VOICES_DIR" ]; then
    cp "$LOG_FILE" "$VOICES_DIR/install.log" 2>/dev/null || true
fi

log ""
log "Install complete."
log "Desktop launcher: $HOME/Desktop/TTS Voice Audition.desktop"
log "Menu entry:       $HOME/.local/share/applications/tts-voice-audition.desktop"
log "Test the voice audition GUI with: bash ~/Voices/audition_voices.sh"
log "Test clipboard speech by copying text, then running: bash ~/Voices/speak_clipboard.sh"
log ""
log "Note about pipx PATH messages:"
log "  If you saw a pipx message about /home/$USER/.local/bin not being on PATH,"
log "  that is normal during first install. The installer handled it for setup,"
log "  and opening a new terminal or logging in again will refresh PATH normally."
log ""
log "------------------------------------------------------------"
log "Keyboard Shortcut Status"
log "------------------------------------------------------------"
if [ -f /tmp/tts_shortcut_status.txt ]; then
    while IFS= read -r LINE; do
        log "$LINE"
    done < /tmp/tts_shortcut_status.txt
else
    log "Shortcut status file not found. Check install.log or run:"
    log "  bash ~/Voices/create_shortcuts.sh"
fi
log "------------------------------------------------------------"
log ""
log "Review the Keyboard Shortcut Status above."
log "If a shortcut set was installed, use the shortcuts shown there."
log "If no shortcuts were installed, see README.txt → Manual Shortcut Creation."

if [ -d "$VOICES_DIR" ]; then
    cp "$LOG_FILE" "$VOICES_DIR/install.log" 2>/dev/null || true
fi

if [ -t 0 ]; then
    echo ""
    echo "Installation finished."
    echo "You may now close this window after reviewing the messages above."
    read -r -p "Press Enter to close this installer window... " _
fi

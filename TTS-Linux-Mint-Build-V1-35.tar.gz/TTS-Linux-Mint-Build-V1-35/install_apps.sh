#!/bin/bash

# =============================================================================
# TTS Linux Mint App Installer
# Installs/verifies Linux packages and edge-tts.
# =============================================================================

set -u
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"

log() { echo "$1"; }

log "Checking internet connection..."
if ! ping -c 1 -W 3 8.8.8.8 >/dev/null 2>&1; then
    log "ERROR: No internet connection detected."
    log "This installer needs internet access to install packages and edge-tts."
    exit 1
fi
log "Internet connection detected."

log ""
log "Installing/verifying required Linux packages..."
sudo apt-get update
sudo apt-get install -y yad mpv socat xclip xsel wl-clipboard pipx

log ""
log "Installing/verifying edge-tts..."
if command -v edge-tts >/dev/null 2>&1; then
    log "edge-tts already available: $(command -v edge-tts)"
elif [ -x "$HOME/.local/bin/edge-tts" ]; then
    log "edge-tts already installed at $HOME/.local/bin/edge-tts"
else
    pipx install edge-tts
fi

# Make pipx apps available in this terminal session without reopening terminal.
export PATH="$HOME/.local/bin:$PATH"

if command -v pipx >/dev/null 2>&1; then
    pipx ensurepath || true
fi

EDGE_TTS_CMD=""
if command -v edge-tts >/dev/null 2>&1; then
    EDGE_TTS_CMD="$(command -v edge-tts)"
elif [ -x "$HOME/.local/bin/edge-tts" ]; then
    EDGE_TTS_CMD="$HOME/.local/bin/edge-tts"
else
    log "ERROR: edge-tts was not found after install."
    exit 1
fi

log "Verifying edge-tts voice list..."
if ! "$EDGE_TTS_CMD" --list-voices >/tmp/tts_voices_test.txt 2>/tmp/tts_edge_verify_error.log; then
    log "ERROR: edge-tts could not list voices."
    cat /tmp/tts_edge_verify_error.log 2>/dev/null || true
    exit 1
fi
log "edge-tts verified."


log ""
log "Installed/available app versions:"
for PKG in yad mpv socat xclip xsel wl-clipboard pipx; do
    if dpkg-query -W -f='${Version}' "$PKG" >/tmp/tts_pkg_version.txt 2>/dev/null; then
        log "  $PKG: $(cat /tmp/tts_pkg_version.txt)"
    else
        log "  $PKG: not found by dpkg-query"
    fi
done
if "$EDGE_TTS_CMD" --version >/tmp/tts_edge_version.txt 2>&1; then
    log "  edge-tts: $(head -1 /tmp/tts_edge_version.txt)"
else
    log "  edge-tts: installed, version command unavailable"
fi
rm -f /tmp/tts_pkg_version.txt /tmp/tts_edge_version.txt

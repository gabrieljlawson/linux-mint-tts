#!/bin/bash

# =============================================================================
# TTS Voice Audition Uninstaller
# Removes only files and shortcuts created by this package.
# Does NOT remove shared applications such as yad, mpv, socat, xclip, pipx, edge-tts.
# =============================================================================

set -u
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$PATH"

USERNAME=$(whoami)
VOICES_DIR="/home/$USERNAME/Voices"
DESKTOP_FILE="$HOME/Desktop/TTS Voice Audition.desktop"
MENU_FILE="$HOME/.local/share/applications/tts-voice-audition.desktop"
SOCKET="/tmp/tts-clipboard-mpvsocket"
CUSTOM_LIST_SCHEMA="org.cinnamon.desktop.keybindings"
CUSTOM_BINDING_SCHEMA="org.cinnamon.desktop.keybindings.custom-keybinding"

# Exact shortcut name -> exact command mapping.
# A shortcut is removed only when BOTH the name and its matching command agree.
TTS_START_NAME="TTS Start Speaking"
TTS_PAUSE_NAME="TTS Pause Resume"
TTS_STOP_NAME="TTS Stop Speaking"

TTS_START_COMMAND="$VOICES_DIR/speak_clipboard.sh"
TTS_PAUSE_COMMAND="$VOICES_DIR/tts_control.sh toggle"
TTS_STOP_COMMAND="$VOICES_DIR/tts_control.sh stop"

confirm() {
    echo "This will remove TTS Voice Audition files, launchers, and TTS keyboard shortcuts."
    echo "It will NOT remove yad, mpv, socat, xclip, pipx, or edge-tts."
    echo ""
    read -r -p "Continue uninstall? [y/N]: " ANSWER
    case "$ANSWER" in
        y|Y|yes|YES|Yes) ;;
        *) echo "Uninstall cancelled."; exit 0 ;;
    esac
}

parse_ids() {
    echo "$1" |
        sed 's/^@as //' |
        tr -d "[]'" |
        tr ',' '\n' |
        sed 's/^ *//;s/ *$//' |
        sed '/^$/d'
}

quote_list() {
    if [ "$#" -eq 0 ]; then
        echo "@as []"
        return
    fi
    local OUT="[" FIRST=1 ITEM
    for ITEM in "$@"; do
        if [ "$FIRST" -eq 1 ]; then
            OUT="$OUT'$ITEM'"
            FIRST=0
        else
            OUT="$OUT, '$ITEM'"
        fi
    done
    OUT="$OUT]"
    echo "$OUT"
}

clean_gsettings_string() {
    sed "s/^'//;s/'$//"
}

get_name_for_id() {
    local ID="$1"
    local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${ID}/"
    gsettings get "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" name 2>/dev/null | clean_gsettings_string || echo ""
}

get_command_for_id() {
    local ID="$1"
    local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${ID}/"
    gsettings get "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" command 2>/dev/null | clean_gsettings_string || echo ""
}

is_matching_tts_shortcut() {
    local NAME="$1"
    local COMMAND="$2"

    case "$NAME" in
        "$TTS_START_NAME")
            [ "$COMMAND" = "$TTS_START_COMMAND" ]
            ;;
        "$TTS_PAUSE_NAME")
            [ "$COMMAND" = "$TTS_PAUSE_COMMAND" ]
            ;;
        "$TTS_STOP_NAME")
            [ "$COMMAND" = "$TTS_STOP_COMMAND" ]
            ;;
        *)
            return 1
            ;;
    esac
}

remove_shortcuts() {
    if ! command -v gsettings >/dev/null 2>&1; then
        echo "gsettings not found; skipping shortcut removal."
        return
    fi

    CURRENT_RAW=$(gsettings get "$CUSTOM_LIST_SCHEMA" custom-list 2>/dev/null || echo "@as []")
    mapfile -t IDS < <(parse_ids "$CURRENT_RAW")

    KEEP_IDS=()
    REMOVED=()
    local ID NAME COMMAND

    for ID in "${IDS[@]}"; do
        NAME=$(get_name_for_id "$ID")
        COMMAND=$(get_command_for_id "$ID")

        if is_matching_tts_shortcut "$NAME" "$COMMAND"; then
            REMOVED+=("$ID ($NAME)")
            local PATH_KEY="/org/cinnamon/desktop/keybindings/custom-keybindings/${ID}/"
            gsettings set "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" binding "@as []" 2>/dev/null || true
            gsettings set "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" command "" 2>/dev/null || true
            gsettings set "${CUSTOM_BINDING_SCHEMA}:${PATH_KEY}" name "" 2>/dev/null || true
        else
            KEEP_IDS+=("$ID")
        fi
    done

    gsettings set "$CUSTOM_LIST_SCHEMA" custom-list "$(quote_list "${KEEP_IDS[@]}")" 2>/dev/null || true

    if [ "${#REMOVED[@]}" -gt 0 ]; then
        echo "Removed TTS shortcuts:"
        for ITEM in "${REMOVED[@]}"; do
            echo "  $ITEM"
        done
        echo "Shortcut removal completed. If Cinnamon still shows an old shortcut, open Keyboard → Shortcuts → Custom Shortcuts once, then close it."
    else
        echo "No matching TTS shortcuts found."
    fi
}

confirm

echo "Stopping active TTS playback..."
pkill -9 mpv >/dev/null 2>&1 || true
pkill -9 -f "edge-tts" >/dev/null 2>&1 || true
rm -f "$SOCKET"

remove_shortcuts

echo "Removing launchers..."
rm -f "$DESKTOP_FILE"
rm -f "$MENU_FILE"

echo "Removing Voices directory..."
rm -rf "$VOICES_DIR"

echo ""
echo "Uninstall complete."
echo "Shared applications were left installed."
echo "If Cinnamon still shows an old shortcut, open Keyboard → Shortcuts → Custom Shortcuts once, then close it."

if [ -t 0 ]; then
    read -r -p "Press Enter to close... " _
fi
